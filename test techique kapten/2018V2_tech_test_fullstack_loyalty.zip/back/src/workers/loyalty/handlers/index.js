'use strict';

const handleSignupEvent = require('./signupEvent');

module.exports = {
  handleSignupEvent,
};
